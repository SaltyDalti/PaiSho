namespace PaiSho.Game
{
    public enum Player
    {
        Host,
        Opponent
    }
}
